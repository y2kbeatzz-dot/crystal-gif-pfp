@echo off
setlocal
title Crystal GIF PFP - FIX EVERYTHING v2.2.4
cd /d "%~dp0"

echo.
echo ==================================================
echo   Crystal GIF PFP - FIX EVERYTHING v2.2.4
echo ==================================================
echo.
echo This updates your existing Crystal extension and Cloudflare Worker.
echo It reuses your EXISTING crystal-shared-pfp D1 database.
echo It does NOT create a second database.
echo.

where node.exe >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js was not found.
  pause
  exit /b 1
)

set "FIXSCRIPT=%TEMP%\crystal-gif-pfp-fix-everything-v224.mjs"

echo Downloading newest repair script to TEMP...
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$out = Join-Path $env:TEMP 'crystal-gif-pfp-fix-everything-v224.mjs'; Invoke-WebRequest -UseBasicParsing 'https://raw.githubusercontent.com/y2kbeatzz-dot/crystal-gif-pfp/main/scripts/fix-everything.mjs' -OutFile $out"
if errorlevel 1 (
  echo ERROR: Could not download the repair script from GitHub.
  echo Expected TEMP path: %FIXSCRIPT%
  pause
  exit /b 1
)

if not exist "%FIXSCRIPT%" (
  echo ERROR: Repair script was not created at %FIXSCRIPT%
  pause
  exit /b 1
)

node.exe "%FIXSCRIPT%"
if errorlevel 1 (
  echo.
  echo ==================================================
  echo   FIX STOPPED
  echo ==================================================
  echo Send the full error above back to ChatGPT.
  pause
  exit /b 1
)

echo.
echo ==================================================
echo   FIX COMPLETE
 echo ==================================================
echo.
echo Reload Crystal GIF PFP in BOTH Chrome profiles,
echo then refresh both YouTube windows.
echo.
pause
